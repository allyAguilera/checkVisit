--
-- PostgreSQL database dump
--

\restrict c7s3DYI7rB0GwfRBFJdLrLMAvZJMSv15VGARsuayH66jHEnwMFjvBFuILpDNWNs

-- Dumped from database version 17.7 (Debian 17.7-3.pgdg13+1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-3.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: departamentos; Type: TABLE; Schema: public; Owner: allysonaguilera
--

CREATE TABLE public.departamentos (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    encargado character varying(100) NOT NULL
);


ALTER TABLE public.departamentos OWNER TO allysonaguilera;

--
-- Name: departamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: allysonaguilera
--

CREATE SEQUENCE public.departamentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departamentos_id_seq OWNER TO allysonaguilera;

--
-- Name: departamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: allysonaguilera
--

ALTER SEQUENCE public.departamentos_id_seq OWNED BY public.departamentos.id;


--
-- Name: visitas; Type: TABLE; Schema: public; Owner: allysonaguilera
--

CREATE TABLE public.visitas (
    id integer NOT NULL,
    nombre_visitante character varying(100) NOT NULL,
    rut character varying(15) NOT NULL,
    motivo text,
    id_departamento integer NOT NULL,
    fecha_ingreso timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_salida timestamp without time zone
);


ALTER TABLE public.visitas OWNER TO allysonaguilera;

--
-- Name: visitas_id_seq; Type: SEQUENCE; Schema: public; Owner: allysonaguilera
--

CREATE SEQUENCE public.visitas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visitas_id_seq OWNER TO allysonaguilera;

--
-- Name: visitas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: allysonaguilera
--

ALTER SEQUENCE public.visitas_id_seq OWNED BY public.visitas.id;


--
-- Name: departamentos id; Type: DEFAULT; Schema: public; Owner: allysonaguilera
--

ALTER TABLE ONLY public.departamentos ALTER COLUMN id SET DEFAULT nextval('public.departamentos_id_seq'::regclass);


--
-- Name: visitas id; Type: DEFAULT; Schema: public; Owner: allysonaguilera
--

ALTER TABLE ONLY public.visitas ALTER COLUMN id SET DEFAULT nextval('public.visitas_id_seq'::regclass);


--
-- Data for Name: departamentos; Type: TABLE DATA; Schema: public; Owner: allysonaguilera
--

COPY public.departamentos (id, nombre, encargado) FROM stdin;
1	101	Carlos Muñoz
2	102	María Gómez
3	103	Ana Torres
4	104	Pedro López
5	105	Lucía Fuentes
6	106	Ricardo Soto
7	107	Fernanda Díaz
8	108	Héctor Silva
9	109	Camila Vargas
10	110	Felipe Rojas
11	201	Andrea Navarro
12	202	Rodrigo Pérez
\.


--
-- Data for Name: visitas; Type: TABLE DATA; Schema: public; Owner: allysonaguilera
--

COPY public.visitas (id, nombre_visitante, rut, motivo, id_departamento, fecha_ingreso, fecha_salida) FROM stdin;
1	Luis Rojas	12345678-9	Entrega de encomienda	1	2025-11-11 06:22:43.901671	2025-11-11 16:38:47.495402
4	ally	186777655-6	reu	1	2025-11-12 01:29:54.478476	\N
5	ally	17766666-4	reu	11	2025-11-12 01:38:53.77907	\N
6	Francisco perez	186777655-6		5	2025-11-17 16:01:20.973399	\N
\.


--
-- Name: departamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: allysonaguilera
--

SELECT pg_catalog.setval('public.departamentos_id_seq', 12, true);


--
-- Name: visitas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: allysonaguilera
--

SELECT pg_catalog.setval('public.visitas_id_seq', 6, true);


--
-- Name: departamentos departamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: allysonaguilera
--

ALTER TABLE ONLY public.departamentos
    ADD CONSTRAINT departamentos_pkey PRIMARY KEY (id);


--
-- Name: visitas visitas_pkey; Type: CONSTRAINT; Schema: public; Owner: allysonaguilera
--

ALTER TABLE ONLY public.visitas
    ADD CONSTRAINT visitas_pkey PRIMARY KEY (id);


--
-- Name: visitas fk_visitas_departamento; Type: FK CONSTRAINT; Schema: public; Owner: allysonaguilera
--

ALTER TABLE ONLY public.visitas
    ADD CONSTRAINT fk_visitas_departamento FOREIGN KEY (id_departamento) REFERENCES public.departamentos(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict c7s3DYI7rB0GwfRBFJdLrLMAvZJMSv15VGARsuayH66jHEnwMFjvBFuILpDNWNs

